# README

## Overview

This repository contains MATLAB code for the main function used in the paper "Multi-scale Correlation Construction for Passive Low-light Imaging with SPAD Camera". The code performs a series of image processing steps, including global photon flux estimation, heterogeneous photon correlation, local fine-tuning, and photon density equalization dimensionality reduction.

## Prerequisites

Ensure you have the following MATLAB toolboxes installed:
- Wavelet Toolbox
- Image Processing Toolbox


## Data Description

### Data Folder

The `Data` folder contains the datasets collected using a SPAD camera under passive low-light conditions.

- **acq00039.mat**: Contains binary raw data for Photon Per Pixel (PPP) of 0.03.
- **duck.mat**: Contains binary data for PPP of 0.9. To reduce data redundancy, some data merging has been performed.

## Usage


### Running the Code

1. Ensure the `Data` folder with the required datasets is in the same directory as the main MATLAB script.
2. Run the `main.m` script in MATLAB.
3. The results will be saved in the `result` folder.

## Citation

If you use this code, please cite the paper:

> Multi-scale Correlation Construction for Passive Low-light Imaging with SPAD Camera

---