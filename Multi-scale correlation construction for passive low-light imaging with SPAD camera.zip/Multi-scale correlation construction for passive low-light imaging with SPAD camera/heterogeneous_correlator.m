function [x_sim_map_set, y_sim_map_set, frame_sim_map_set, ind_srch, R] = heterogeneous_correlator...
    (pseudo_i_map_set, N_x, N_y, N_c, N_sim, C_size, R_intra, R_inter)


max_buffer_size = (2 * R_intra + 1) * (2 * R_intra + 1) * (2 * R_inter + 1);
dist_buffer = zeros(max_buffer_size, 1);
x_buffer = nan(max_buffer_size, 1);
y_buffer = nan(max_buffer_size, 1);
frame_buffer = nan(max_buffer_size, 1);


x_sim_map_set = zeros(N_y, N_x, N_sim, N_c);
y_sim_map_set = zeros(N_y, N_x, N_sim, N_c);
frame_sim_map_set = zeros(N_y, N_x, N_sim, N_c);


S_intra = 2 * R_intra + 1;  
S_inter = 2 * R_inter + 1;  
block_size = C_size * C_size;

for frame = 1:N_c
    disp(['frame', num2str(frame), ':']);  
    for y = 1:N_y - (C_size - 1)  
        for x = 1:N_x - (C_size - 1)
            
            
            reference_block = pseudo_i_map_set(y:y+(C_size-1), x:x+(C_size-1), frame);
            reference_vector = reference_block(:);
            ref_dist = sum(reference_vector .^ 2);
            
            
            buffer_count = 0;
            buffer_idx = 1;
            
            
            for frame_srch = max(frame - R_inter, 1):min(frame + R_inter, N_c)
                for y_srch = max(y - R_intra, 1):min(y + R_intra, N_y - (C_size - 1))
                    for x_srch = max(x - R_intra, 1):min(x + R_intra, N_x - (C_size - 1))
                       
                        if frame_srch == frame && y_srch == y && x_srch == x
                            continue;
                        end
                        
                       
                        search_block = pseudo_i_map_set(y_srch:y_srch+(C_size-1), x_srch:x_srch+(C_size-1), frame_srch);
                        search_vector = search_block(:);
                        
                        
                        dist = sum((reference_vector - search_vector) .^ 2);
                        
                        
                        buffer_count = buffer_count + 1;
                        dist_buffer(buffer_count) = dist;
                        x_buffer(buffer_count) = x_srch;
                        y_buffer(buffer_count) = y_srch;
                        frame_buffer(buffer_count) = frame_srch;

                        if dist < ref_dist
                            buffer_idx = buffer_count;
                            ref_dist = dist;
                        end
                    end
                end
            end
            
           
            [~, sorted_idx] = sort(dist_buffer(1:buffer_count));
            sorted_idx = sorted_idx(1:N_sim);
            
          
            x_sim_map_set(y, x, :, frame) = x_buffer(sorted_idx);
            y_sim_map_set(y, x, :, frame) = y_buffer(sorted_idx);
            frame_sim_map_set(y, x, :, frame) = frame_buffer(sorted_idx);
        end
    end
end