function i_diff = dimensionality_reduction(clane_map, i_map_set)
    
    i_clane = sum(clane_map, 3);
    i_raw = sum(i_map_set, 3);
    
    
    i_raw_fliter = medfilt2(i_raw, [3 3]);
    i_clane_fliter = medfilt2(i_clane, [3 3]);
    

    i_diff = i_raw_fliter - i_clane_fliter;
    i_diff = medfilt2(i_diff, [2 2]); 
    i_diff = i_diff / prctile(i_diff(:), 99);
    
   
    figure; imshow(i_diff); title('result intensity');
end