function denoisedData = wavelet(inputData)

    wavename = 'sym4'; 
    level = 3;
    k = 0.3;
    
    
    [m, n, p] = size(inputData);
    denoisedData = zeros(m, n, p);
    
    for i = 1:p
       
        [C, S] = wavedec2(inputData(:,:,i), level, wavename);
       
        for j = 1:level
            first = prod(S(1:j, :)) + 1;
            last = prod(S(1:j+1, :));
            
         
            if last <= length(C)
                coefficients = abs(C(first:last));
            else
                coefficients = abs(C(first:end));
            end
            
          
            neighborhoodMean = mean(coefficients);

            
            threshold = k * neighborhoodMean;

            
         
            if last <= length(C)
                C(first:last) = wthresh(C(first:last), 's', threshold);
            else
                C(first:end) = wthresh(C(first:end), 's', threshold);
            end
        end
        
        denoisedPlane = waverec2(C, S, wavename);
        denoisedData(:,:,i) = denoisedPlane;
    end
end