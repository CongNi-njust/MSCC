function flux_map = estimate_init_flux_wavelet(i_map_set, x_sim_map_set, y_sim_map_set, frame_sim_map_set, N_y, N_x, N_t, N_sim, N_c, C_size)
    
    flux_map = zeros(N_y, N_x, N_t);  
    weight_sum_map_set = zeros(N_y, N_x); 

    
    for frame = 1:N_t   
        disp(['frame ', num2str(frame), ':']);
        
       
        for y = 1:C_size:N_y - (C_size - 1)
           
            for x = 1:C_size:N_x - (C_size - 1)
                
               
                FLUX_noisy_cubelet_set3D = zeros(C_size, C_size, N_sim); 
                
               
                for sim_idx = 1:N_sim
                   
                    y_sim = y_sim_map_set(y, x, sim_idx);
                    x_sim = x_sim_map_set(y, x, sim_idx);
                    frame_sim = frame_sim_map_set(y, x, sim_idx);
                    
                   
                    if y_sim > N_y - C_size + 1 || x_sim > N_x - C_size + 1 || frame_sim > N_t
                        error(['Index out of bounds: y_sim=', num2str(y_sim), ', x_sim=', num2str(x_sim), ', frame_sim=', num2str(frame_sim)]);
                    end

                  
                    FLUX_noisy_cubelet = i_map_set(y_sim:y_sim+C_size-1, x_sim:x_sim+C_size-1, frame_sim);
                   
                  
                    [C, L] = wavedec2(FLUX_noisy_cubelet, 2, 'db1'); 
                    FLUX_noisy_cubelet_recon = waverec2(C, L, 'db1');
                    
                  
                    FLUX_noisy_cubelet_set3D(:, :, sim_idx) = FLUX_noisy_cubelet_recon;
                end
                
               
                MSE = mean(abs(FLUX_noisy_cubelet_set3D(:)).^2);

             
                weight = 1 / (MSE + eps);
                weight_sum_map_set(y:y+C_size-1, x:x+C_size-1) = weight_sum_map_set(y:y+C_size-1, x:x+C_size-1) + weight;
                
                
                flux_cubelet_set = zeros(C_size, C_size, N_t);
                for sim_idx = 1:N_sim
                    [C, L] = wavedec2(FLUX_noisy_cubelet_set3D(:, :, sim_idx), 2, 'db1');
                    flux_cubelet_set(:, :, sim_idx) = waverec2(C, L, 'db1');
                end
                
                
                flux_map(y:y+C_size-1, x:x+C_size-1, frame) = ...
                    flux_map(y:y+C_size-1, x:x+C_size-1, frame) + weight * sum(flux_cubelet_set, 3);
            end
        end
    end

 
    flux_map = flux_map ./ repmat(weight_sum_map_set, [1, 1, N_t]);

    
    flux_map(flux_map < 0) = 0;
end