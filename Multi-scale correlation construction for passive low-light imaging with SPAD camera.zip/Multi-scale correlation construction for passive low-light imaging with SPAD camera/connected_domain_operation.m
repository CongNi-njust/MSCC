function [connected_data] = connected_domain_operation(denoisedData)

V = denoisedData;


se = strel('cube', 1); 


closedV = imclose(V, se);
closedV = imclose(closedV, se);
closedV = imclose(closedV, se);



openedV = imopen(closedV, se);
openedV = imopen(openedV, se);
openedV = imopen(openedV, se);


finalV = imdilate(openedV, se);
finalV = imdilate(finalV, se);
finalV = imdilate(finalV, se);

connected_data = finalV;

end