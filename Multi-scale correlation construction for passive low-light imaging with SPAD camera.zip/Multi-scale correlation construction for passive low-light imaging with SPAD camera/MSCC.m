clc;
clear all;
%% load data

% load('duck.mat', 'dark09_10frame')
%% load data
dataFolder = fullfile(pwd, 'Data');
load(fullfile(dataFolder, 'duck.mat'), 'dark09_10frame');


%% global photon flux estimation

connected_frames_binary = connected_domain_operation(dark09_10frame);

denoisedData = waveletDenoising(connected_frames_binary, 'sym4', 3, 0.1);


% photon cube size
N_y = size(denoisedData, 1);                 
N_x = size(denoisedData, 2);                 
N_t = size(denoisedData, 3); 
N_c = size(denoisedData, 4);                
i_map_set = denoisedData;
%% heterogeneous photon correlator   
 
N_sim = 5; C_size = 5; R_intra = 5; R_inter = 0;


[x_sim_map_set, y_sim_map_set, frame_sim_map_set] = heterogeneous_correlator(denoisedData, N_x, N_y, N_c, N_sim, C_size, R_intra, R_inter);

%% local fine-tuning


flux_map_set = estimate_init_flux_wavelet...
    (i_map_set, x_sim_map_set, y_sim_map_set, frame_sim_map_set, ...
    N_y, N_x, N_t, N_sim,N_c, C_size);



%% photon density equlization dimensionality reduction

clane_map = clane(flux_map_set, 5, 5, 0.1);

i_diff_result = dimensionality_reduction(clane_map, i_map_set);


%% save results
resultFolder = fullfile(pwd, 'result');
if ~exist(resultFolder, 'dir')
    mkdir(resultFolder);
end
save(fullfile(resultFolder, 'results.mat'), 'clane_map', 'i_diff_result');
