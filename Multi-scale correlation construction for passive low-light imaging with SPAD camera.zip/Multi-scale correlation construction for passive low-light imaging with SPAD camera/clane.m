function enhancedMatrix = clane(inputMatrix, neighborhoodSize, sigma, clipLimit)
    [M, N, P] = size(inputMatrix);
    enhancedMatrix = zeros(M, N, P); 
   
   
    for p=1:P
        
        meanImg = imgaussfilt(inputMatrix(:, :, p), sigma);
        
        
        contrast = inputMatrix(:, :, p) ./ (meanImg + eps);
        
       
        enhancedContrast = adapthisteq(contrast, 'NumTiles', [floor(M/neighborhoodSize), floor(N/neighborhoodSize)], 'ClipLimit', clipLimit);
        
        
        contrastGain = mean(enhancedContrast, 'all');
        
        
        enhancedMatrix(:, :, p) = inputMatrix(:, :, p) .* contrastGain;
         
       
        enhancedMatrix(:, :, p) = imadjust(enhancedMatrix(:, :, p), [], [], 1/contrastGain);
    end
end